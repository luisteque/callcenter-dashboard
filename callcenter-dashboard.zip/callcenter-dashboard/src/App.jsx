import React from "react";

const empleados = [
  { nombre: "Juan Pérez", productividad: 95, area: "Tarjetas de crédito" },
  { nombre: "Ana López", productividad: 90, area: "Disponible puro" },
  { nombre: "Carlos Ruiz", productividad: 85, area: "Préstamos personales" },
];

const App = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Dashboard Call Center</h1>
      <h2>Empleados</h2>
      <ul>
        {empleados.map((e, i) => (
          <li key={i}>
            {e.nombre} - {e.area} - Productividad: {e.productividad}%
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;